package command;

/**
 * 
 * Interface CommandGeneral
 * 
 * @since v2
 * @author Alexis LE MASLE et Fanny PRIEUR
 *
 */
public interface CommandGeneral {

	/**
	 * Methode execute commune a toutes les commandes Concretes
	 */
	void execute();

}

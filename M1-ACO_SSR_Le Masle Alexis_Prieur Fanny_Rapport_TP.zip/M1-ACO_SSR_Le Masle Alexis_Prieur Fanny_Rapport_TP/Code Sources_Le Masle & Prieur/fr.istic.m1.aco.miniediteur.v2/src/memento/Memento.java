package memento;

/**
 * Interface Memento
 *
 * @since v2
 * @author Alexis LE MASLE et Fanny PRIEUR
 */
public interface Memento<T> {

}

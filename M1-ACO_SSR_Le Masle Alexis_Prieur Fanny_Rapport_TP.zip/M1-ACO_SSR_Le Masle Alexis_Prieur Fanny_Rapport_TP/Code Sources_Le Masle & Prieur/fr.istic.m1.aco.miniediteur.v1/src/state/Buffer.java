package state;

public class Buffer {

	private StringBuffer buffer = new StringBuffer("");

	public Buffer() {
	}

	public StringBuffer getBuffer() {
		return buffer;
	}

	public void setBuffer(StringBuffer buffer) {
		this.buffer = buffer;
	}

}

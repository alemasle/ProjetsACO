package state;

public class Selection {

	private int debut = 0;
	private int fin = 0;

	public Selection() {

	}

	/**
	 * @return le debut
	 */
	public int getDebut() {
		return debut;
	}

	/**
	 * @param debut
	 *            le debut a definir
	 */
	public void setDebut(int debut) {
		this.debut = debut;
	}

	/**
	 * @return le fin
	 */
	public int getFin() {
		return fin;
	}

	/**
	 * @param fin
	 *            le fin a definir
	 */
	public void setFin(int fin) {
		this.fin = fin;
	}

}

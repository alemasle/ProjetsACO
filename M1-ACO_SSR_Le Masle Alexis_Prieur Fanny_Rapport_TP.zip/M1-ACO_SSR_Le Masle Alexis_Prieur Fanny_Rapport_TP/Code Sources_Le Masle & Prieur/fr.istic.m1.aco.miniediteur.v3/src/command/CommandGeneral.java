package command;

/**
 * 
 * Interface CommandGeneral
 * 
 * @author Alexis LE MASLE et Fanny PRIEUR
 *
 */
public interface CommandGeneral {

	/**
	 * Methode execute() commune a toutes les commandes Concretes
	 */
	void execute();

}

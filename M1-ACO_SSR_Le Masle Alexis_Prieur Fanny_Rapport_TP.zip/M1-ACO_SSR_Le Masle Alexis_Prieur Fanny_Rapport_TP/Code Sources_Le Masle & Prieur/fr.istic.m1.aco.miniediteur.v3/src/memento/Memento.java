package memento;

/**
 * Interface Memento
 *
 * @author Alexis LE MASLE et Fanny PRIEUR
 */
public interface Memento<T> {

	Memento<T> clone();

}
